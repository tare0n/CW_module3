# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cw_module3']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['get-banch = cw_module3.main:get_banch',
                     'get-sorted = cw_module3.main:get_sorted']}

setup_kwargs = {
    'name': 'cw-module3',
    'version': '0.1.0',
    'description': '',
    'long_description': '# course work for module 3: poetry and algorithms',
    'author': 'tare0n',
    'author_email': 'msktareo@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
